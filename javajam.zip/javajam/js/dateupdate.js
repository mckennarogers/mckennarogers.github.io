document.getElementById("dateupdate").innerHTML = "Page Updated" + document.lastModified;
